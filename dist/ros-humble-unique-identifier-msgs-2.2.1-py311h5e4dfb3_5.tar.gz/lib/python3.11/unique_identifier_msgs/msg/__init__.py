from unique_identifier_msgs.msg._uuid import UUID  # noqa: F401
